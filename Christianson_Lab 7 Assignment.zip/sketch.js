

function setup() {

	createCanvas(500, 500);
  
   var yourWeight = 135;

	// call function and pass the variable yourWeight into it

	var moonWeight = calculateMoon(yourWeight);

	// output variable marsWeight to console

	print(moonWeight);
}

function draw() {

	background(204);

	for (var x = 0; x < width + 150; x += 220) {
		emoji(x, 110);
    }
  
  angleMode(RADIANS);
  rotate(QUARTER_PI);
  scale(0.5);
  emoji(925,25);// calling the 'emoji' function, passing x and y position coordinates

  
	
}

function emoji(x, y) {

	push(); // create a new drawing state

	translate(x, y);

	fill(255);
  
    strokeWeight(5);
  
  rect(-10,0,300,200);
  
	ellipse(105,100,175,175);
  
    noStroke();

	fill(0);

	ellipse(70, 75, 50, 50); // Left eye Outer

	ellipse(140, 75, 50, 50); // Right eye Outer
  
    arc(105, 120, 70, 70, 0, PI); // Mouth
  
    fill(255);
  
    arc(105, 120, 60, 60, 0, PI); // Mouth Inner
  
    ellipse(73, 76, 40, 40); // Left eye Iris

	ellipse(143, 76, 40, 40); // Right eye Iris
  
    fill(0);

    ellipse(78, 76, 20, 20); // Left eye Pupil

	ellipse(148, 76, 20, 20); // Right eye Pupil
  
	pop(); // return the drawing state to it's original state, before the push() function

}

function calculateMoon(w) {

// the function uses this 'w' variable value in calculating a variable call newWeight

	var newWeight = w * 0.165;

// the variable newWeight value is returned  to the line where the function was called, there it is assigned to the variable moonWeight

	return newWeight;
}