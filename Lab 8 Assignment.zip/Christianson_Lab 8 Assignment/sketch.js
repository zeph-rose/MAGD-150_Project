
var img1;
var img2;
var img3;

function preload() {

	img1 = loadImage("cumulus-clouds.jpg");
	img2 = loadImage("cumulonimbus-clouds.jpg");
    img3 = loadImage("transparent-cloud.png");

}

function setup () {

	createCanvas(700, 400);

      textFont("Arial");
  
}

function draw () {

	background(204);
  
	image(img1, 0, 0, 240, 120);

	image(img2, 250, 0, 240, 120);
  
    image(img3, 0, 0, mouseX * 2, mouseY * 2);
  
  textSize(28);

	text("Cumulus Clouds", 5, 160);
  
  text("Cumulonimbus Clouds", 255, 160);
  
  
}