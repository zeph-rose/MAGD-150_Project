let colorGen;

function setup() {
    createCanvas(600, 800);
    colorGen = new ColorGenerator(); // Initialize with base color
    push();
    let shades = colorGen.getShades(5);
    
    shades.forEach((shade, index) => {
        fill(shade);
        rect(index * 100, 0, 100, 100); // Draw shades
    });
    pop();

    push();
       let tints = colorGen.getTints(5); // Generate 5 tints

tints.forEach((tint, index) => {
    fill(tint);
    rect(index * 100, 100, 100, 100);
});
pop();

push();

   let mono = colorGen.getMonochromatic(5, true, false); // Generate 5 monochromatic colors with increasing saturation

mono.forEach((color, index) => {
    fill(color);
    rect(index * 100, 200, 100, 100);
});
pop();

push();
let complementary = colorGen.getComplementary();

complementary.forEach((color, index) => {
    fill(color);
    rect(index * 100, 300, 100, 100);
});
pop();

push();
let triadic = colorGen.getTriadic();

triadic.forEach((color, index) => {
    fill(color);
    rect(index * 100, 400, 100, 100);
});
pop();

push();
let analogous = colorGen.getAnalogous(30);

analogous.forEach((color, index) => {
    fill(color);
    rect(index * 100, 500, 100, 100);
});
pop();

push();
let splitComp = colorGen.getSplitComplementary();

splitComp.forEach((color, index) => {
    fill(color);
    rect(index * 100, 600, 100, 100);
});
pop();

push();
let tetradic = colorGen.getTetradic();

tetradic.forEach((color, index) => {
    fill(color);
    rect(index * 100, 700, 100, 100);
});
pop();

};
